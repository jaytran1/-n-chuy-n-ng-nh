-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Dec 15, 2020 at 08:36 PM
-- Server version: 5.7.28
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elaravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `donhang`
--

DROP TABLE IF EXISTS `donhang`;
CREATE TABLE IF NOT EXISTS `donhang` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idKhachhang` int(10) UNSIGNED NOT NULL,
  `TenSp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Soluong` int(11) NOT NULL DEFAULT '0',
  `Thanhtien` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `donhang_idKhachhang_foreign` (`idKhachhang`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `donhang`
--

INSERT INTO `donhang` (`id`, `idKhachhang`, `TenSp`, `Soluong`, `Thanhtien`, `created_at`, `updated_at`) VALUES
(9, 11, 'Cà phê rượu sữa limited', 1, 2000000, '2020-12-15 20:31:17', '2020-12-15 20:31:17');

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

DROP TABLE IF EXISTS `hoadon`;
CREATE TABLE IF NOT EXISTS `hoadon` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idKhachhang` int(10) UNSIGNED NOT NULL,
  `TenKh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ngaysinh` date DEFAULT NULL,
  `diachi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinhthuctt` int(1) NOT NULL DEFAULT '1',
  `Thanhtien` int(11) NOT NULL DEFAULT '0',
  `trangthai` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hoadon_idKhachhang_foreign` (`idKhachhang`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`id`, `idKhachhang`, `TenKh`, `email`, `ngaysinh`, `diachi`, `sdt`, `hinhthuctt`, `Thanhtien`, `trangthai`, `created_at`, `updated_at`) VALUES
(14, 12, 'teo', 'teo@boomhang', '2020-12-10', '5/5', '9999999999', 1, 7300000, 1, '2020-12-15 19:54:39', '2020-12-15 19:54:39'),
(15, 12, 'teo', 'teo@boomhang', NULL, '5/5', '99999999998', 1, 7300000, 1, '2020-12-15 19:55:49', '2020-12-15 19:55:49'),
(16, 11, 'ngheo', 'ngheo@trum', NULL, '5/5', '6666666666', 1, 2000000, 1, '2020-12-15 20:32:20', '2020-12-15 20:32:20');

-- --------------------------------------------------------

--
-- Table structure for table `loaitin`
--

DROP TABLE IF EXISTS `loaitin`;
CREATE TABLE IF NOT EXISTS `loaitin` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idTheLoai` int(10) UNSIGNED NOT NULL,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loaitin_idtheloai_foreign` (`idTheLoai`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaitin`
--

INSERT INTO `loaitin` (`id`, `idTheLoai`, `Ten`, `TenKhongDau`, `created_at`, `updated_at`) VALUES
(29, 11, 'ca phe chon 123', 'ca-phe-chon-123', '2020-12-04 16:50:31', '2020-12-04 17:20:41'),
(30, 10, 'ca phe rabusta', 'ca-phe-rabusta', '2020-12-04 17:06:14', '2020-12-04 17:06:14'),
(31, 11, 'cà phê mèo', 'ca-phe-meo', '2020-12-04 17:35:55', '2020-12-04 17:35:55'),
(33, 11, 'Cà phê dolgona', 'ca-phe-dolgona', '2020-12-07 04:59:13', '2020-12-07 04:59:13'),
(34, 10, 'Arabica Dalat', 'arabica-dalat', '2020-12-07 05:00:33', '2020-12-07 05:00:33'),
(35, 10, 'Espresso', 'espresso', '2020-12-07 06:56:18', '2020-12-07 06:56:18'),
(36, 11, 'ruou sua', 'ruou-sua', '2020-12-07 07:21:33', '2020-12-07 07:21:33'),
(37, 10, 'ruou sua vjp', 'ruou-sua-vjp', '2020-12-07 07:24:28', '2020-12-07 07:24:28');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

DROP TABLE IF EXISTS `slide`;
CREATE TABLE IF NOT EXISTS `slide` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Hinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NoiDung` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `theloai`
--

DROP TABLE IF EXISTS `theloai`;
CREATE TABLE IF NOT EXISTS `theloai` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TenKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `theloai`
--

INSERT INTO `theloai` (`id`, `Ten`, `TenKhongDau`, `created_at`, `updated_at`) VALUES
(10, 'Cà phê thượng hạng', 'ca-phe-thuong-hang', '2020-12-04 16:42:41', '2020-12-07 07:35:14'),
(11, 'Cà phê thường', 'ca-phe-thuong', '2020-12-04 16:42:49', '2020-12-04 17:35:31');

-- --------------------------------------------------------

--
-- Table structure for table `tintuc`
--

DROP TABLE IF EXISTS `tintuc`;
CREATE TABLE IF NOT EXISTS `tintuc` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `TieuDe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TieuDeKhongDau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TomTat` text COLLATE utf8_unicode_ci NOT NULL,
  `NoiDung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `Hinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NoiBat` int(11) NOT NULL DEFAULT '0',
  `Gia` int(11) NOT NULL DEFAULT '0',
  `idLoaiTin` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tintuc_idloaitin_foreign` (`idLoaiTin`)
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tintuc`
--

INSERT INTO `tintuc` (`id`, `TieuDe`, `TieuDeKhongDau`, `TomTat`, `NoiDung`, `Hinh`, `NoiBat`, `Gia`, `idLoaiTin`, `created_at`, `updated_at`) VALUES
(1003, 'Ca phe Rabusta', 'ca-phe-rabusta', 'fsdf', 'sdfs', '4iC_rabusta.jpg', 0, 800000, 30, '2020-12-04 17:09:42', '2020-12-08 18:30:25'),
(1004, 'Cà phê chồn', 'ca-phe-chon', 'woop woop', 'woop woop', 'iOn_ca phe chon.png', 0, 600000, 29, '2020-12-04 17:22:41', '2020-12-07 06:54:02'),
(1006, 'Cà phê mèo', 'ca-phe-meo', 'meomeo', 'meo` meo\' meo meo` meo', 'Y77_ca phe meo.png', 0, 500000, 31, '2020-12-07 04:56:20', '2020-12-07 06:53:16'),
(1007, 'Cà phê dolgona', 'ca-phe-dolgona', 'dolgona', 'dolgona', 'p7Y_dolgona.jpg', 0, 400000, 33, '2020-12-07 04:59:43', '2020-12-07 06:52:56'),
(1008, 'Arabica Dalat', 'arabica-dalat', 'asdasd', 'asdadad', 'SwG_arabica.jpg', 0, 1500000, 34, '2020-12-07 05:01:32', '2020-12-07 07:18:29'),
(1009, 'Cà phê Espresso', 'ca-phe-espresso', 'vjppro', 'vjppro', 'Mny_cafe espresso.jpg', 1, 1400000, 35, '2020-12-07 06:56:53', '2020-12-07 06:56:53'),
(1010, 'Cà phê rượu sữa', 'ca-phe-ruou-sua', 'awyeh', 'awyeh', 'x4I_ruou-sua-coffee-sheridans.jpg', 0, 700000, 36, '2020-12-07 07:22:55', '2020-12-07 07:22:55'),
(1011, 'Cà phê rượu sữa limited', 'ca-phe-ruou-sua-limited', 'abcxyz', 'abcxyz', 'wRk_ruou-sua-coffee-sheridans.jpg', 0, 2000000, 37, '2020-12-07 07:25:06', '2020-12-07 07:25:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quyen` int(11) NOT NULL DEFAULT '0',
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `quyen`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(11, 'Admin', 'long@gmail.com', 1, '$2y$10$8D2tOCNk1VG0vrZCKW.VEeVjTBjwsDx3ZTh6pPtIAkk9AF2F3U9w2', NULL, '2020-12-04 16:22:11', '2020-12-08 20:18:52'),
(12, 'khach  hang', 'khach@gmail.com', 0, '$2y$10$2rx5PkQbqGKsMibA3JmsseS22sisdBrpkfa6unH0L7c9tzlA24EDS', NULL, '2020-12-08 20:02:11', '2020-12-08 20:02:11'),
(13, 'admin', 'admin@gmail.com', 1, '$2y$10$DFMeA0f3hyZtEUbRHLgGz.WzNlOmjnmHdamfUWwH74lVB07e4A4rm', NULL, '2020-12-08 20:08:16', '2020-12-08 20:08:16');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donhang`
--
ALTER TABLE `donhang`
  ADD CONSTRAINT `comment_iduser_foreign` FOREIGN KEY (`idKhachhang`) REFERENCES `users` (`id`);

--
-- Constraints for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD CONSTRAINT `hoadon_iduser_foreign` FOREIGN KEY (`idKhachhang`) REFERENCES `users` (`id`);

--
-- Constraints for table `loaitin`
--
ALTER TABLE `loaitin`
  ADD CONSTRAINT `loaitin_idtheloai_foreign` FOREIGN KEY (`idTheLoai`) REFERENCES `theloai` (`id`);

--
-- Constraints for table `tintuc`
--
ALTER TABLE `tintuc`
  ADD CONSTRAINT `tintuc_idloaitin_foreign` FOREIGN KEY (`idLoaiTin`) REFERENCES `loaitin` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
